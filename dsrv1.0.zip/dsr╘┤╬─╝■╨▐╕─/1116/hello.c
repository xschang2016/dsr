#include <linux/module.h>      /* Needed by all modules */
#include <linux/kernel.h>      /* Needed for KERN_INFO */
#include <linux/fs.h>
#include<linux/slab.h>
#include <linux/uaccess.h>
#include<linux/timer.h>
MODULE_LICENSE("GPL");
static struct timer_list my_timer ;
char *buf=NULL;
char *sbuf=NULL;
int total=0;
inline void vfswr(char *sbuf,unsigned long size){
//inline void vfswr(unsigned long data){
    struct file *fp;
    mm_segment_t fs;
    static loff_t pos=0;
    fp =filp_open("/home/cxs/Desktop/storage.txt",O_RDWR | O_CREAT | O_APPEND,0644);
    if (IS_ERR(fp)){
        printk("create file error/n");
        return ;
    }
    fs =get_fs();
    set_fs(KERNEL_DS);
    vfs_write(fp,sbuf,total,&pos);
    filp_close(fp,NULL);
    del_timer( &my_timer);  
    set_fs(fs);
}
struct ch{
char a;
char b;
char c[2];
};
struct num{
int a;
int b;
int c[2];
};
struct udphdr {
 __be16 source; //16位源端口号
 __be16 dest;  //16位目的端口号
 __be16 len;  
 __sum16 check; 
};
struct iphdr {
    __u8    ihl:4,
            version:4;
    __u8    tos;
    __be16  tot_len;
    __be16  id;
    __be16  frag_off;
    __u8    ttl;
    __u8    protocol;
    __be16  check;
    __be32  saddr;
    __be32  daddr;
};

struct ethhdr
{
    unsigned char h_dest[ETH_ALEN];
    unsigned char h_source[ETH_ALEN]; 
    __u16 h_proto ; 
}
/*void timer_handler( unsigned long data )
{    
	vfswr(sbuf,total);
	my_timer.expires = jiffies + 2*HZ ;
	add_timer( &my_timer );                   
	return ;    
}*/
void timer(void)                     
{
    init_timer( &my_timer );
    my_timer.data = 0 ;
    my_timer.expires = jiffies + 2*HZ ;
    my_timer.function = vfswr;
    add_timer( &my_timer );
    return  ;

}
void aa(){
vfswr(sbuf,total);
}
void test(){
int a,b;
a=10;
b=30;
printk("%d\n",a);
aa();
//vfswr(sbuf,total);


}
static int __init my_init(void)
{
buf=(char *)kmalloc(1024*sizeof(char),GFP_ATOMIC);
sbuf=buf;
int i=0,n=0;
struct ch *nch=(struct ch *)kmalloc(sizeof(struct ch),GFP_ATOMIC);
nch->a='a';
nch->b='b';
nch->c[0]='a';
nch->c[1]='b';
struct num *nnum=(struct num *)kmalloc(sizeof(struct num),GFP_ATOMIC);
nnum->a=1;
nnum->b=2;
nnum->c[0]=1;
nnum->c[1]=2;
struct udphdr *udp=(struct udphdr *)kmalloc(sizeof struct udphdr,GFP_ATOMIC);
udphdr->
struct iphdr *ip=(struct iphdr *)kmalloc(sizeof struct iphdr,GFP_ATOMIC);
struct ethhdr *eth=(struct ethhdr *)kmalloc(sizeof struct udphdr,GFP_ATOMIC);
char *pch=(char *)nch;
char *pnum=(char *)nnum;
while(i++<102){
memcpy(buf,pch,sizeof(*nch));
buf+=sizeof(*nch);
memcpy(buf,pnum,sizeof(*nnum));
buf+=sizeof(*nnum);
total=sizeof(*nch)+sizeof(*nnum);
}
 test();
return 0;
}


static void __exit my_exit(void)
{   //kfree(nnum);
    //kfree(pch);
    kfree(sbuf);
    kfree(buf);
    printk("<1>Exiting...\n");
    del_timer( &my_timer);      
    printk("<1>Byebye! \n");    
    return ;
}


module_init(my_init);
module_exit(my_exit);
