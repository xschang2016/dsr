 #include <linux/kthread.h>
#include <linux/module.h>
#include <linux/kernel.h>      /* Needed for KERN_INFO */
#include <linux/fs.h>
#include<linux/slab.h>
#include <linux/uaccess.h>
#include<linux/timer.h>
#include<linux/spinlock.h>
#ifndef SLEEP_MILLI_SEC
#define SLEEP_MILLI_SEC(nMilliSec)\
do { \
long timeout = (nMilliSec) * HZ / 1000; \
while(timeout > 0) \
{ \
timeout = schedule_timeout(timeout); \
} \
}while(0);
#endif
struct ch{
char a;
char b;
char c[2];
};
struct num{
int a;
int b;
int c[2];
};
static struct task_struct * MyThread = NULL;
char *buf=NULL;
char *sbuf=NULL;
int total=0;
void vfswr(char *sbuf,unsigned long size){
    struct file *fp;
    mm_segment_t fs;
   static loff_t pos;
    fp =filp_open("/home/cxs/Desktop/storage.txt",O_APPEND | O_RDWR | O_CREAT,0644);
    if (IS_ERR(fp)){
        printk("create file error/n");
        return ;
    }
    fs =get_fs();
    set_fs(KERNEL_DS);
    pos =0;
    vfs_write(fp,sbuf,size,&pos);
    filp_close(fp,NULL);
    set_fs(fs);
}
static int MyPrintk(void *data)
{
char *mydata = kmalloc(strlen(data)+1,GFP_KERNEL);
memset(mydata,'\0',strlen(data)+1);
strncpy(mydata,data,strlen(data));
while(!kthread_should_stop())
{
SLEEP_MILLI_SEC(50);
vfswr(mydata,strlen(data));
}
kfree(mydata);
return 0;
}
static int __init init_kthread(void)
{
buf=(char *)kmalloc(1024*sizeof(char),GFP_ATOMIC);
sbuf=buf;
int i=0,n=0;
struct ch *nch=(struct ch *)kmalloc(sizeof(struct ch),GFP_ATOMIC);
nch->a='a';
nch->b='b';
nch->c[0]='a';
nch->c[1]='b';
struct num *nnum=(struct num *)kmalloc(sizeof(struct num),GFP_ATOMIC);
nnum->a=1;
nnum->b=2;
nnum->c[0]=1;
nnum->c[1]=2;
char *pch=(char *)nch;
char *pnum=(char *)nnum;
memcpy(buf,pch,sizeof(*nch));
buf+=sizeof(*nch);
memcpy(buf,pnum,sizeof(*nnum));
total=sizeof(*nch)+sizeof(*nnum);
MyThread = kthread_run(MyPrintk,sbuf,"mythread");
return 0;
}
static void __exit exit_kthread(void)
{
if(MyThread)
{
printk("stop MyThread\n");
kthread_stop(MyThread);
}
}
module_init(init_kthread);
module_exit(exit_kthread);
