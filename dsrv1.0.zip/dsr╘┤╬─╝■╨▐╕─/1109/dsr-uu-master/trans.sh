scp *ko* root@1.1.1.$1:/root/dsrko
