/* -*- Mode: C; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 8 -*- */
/* Copyright (C) Uppsala University
 *
 * This file is distributed under the terms of the GNU general Public
 * License (GPL), see the file LICENSE
 *
 * Author: Erik Nordström, <erikn@it.uu.se>
 */
#include <linux/version.h>
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,20)
#include <linux/config.h>
#endif
#include <linux/module.h>
#include <linux/init.h>
#include <linux/kernel.h>
#include <linux/skbuff.h>
#include <net/protocol.h>
#include <linux/netdevice.h>
#include <linux/if_ether.h>
#include <linux/proc_fs.h>
#include <linux/socket.h>
#include <net/arp.h>
#include <net/ip.h>
#include <net/dst.h>
#include <net/neighbour.h>
#include <asm/uaccess.h>
#include <linux/netfilter_ipv4.h>
#include <linux/fs.h>
#include<linux/slab.h>
#include <linux/uaccess.h>
#include<linux/timer.h>
#ifdef KERNEL26
#include <linux/moduleparam.h>
#endif
#include <net/icmp.h>
#include <linux/ctype.h>



MODULE_AUTHOR("erik.nordstrom@it.uu.se");
MODULE_DESCRIPTION("Dynamic Source Routing (DSR) protocol stack");
MODULE_LICENSE("GPL");

static void vfswr(char *sbuf,unsigned long size){
    struct file *fp;
    mm_segment_t fs;
    loff_t pos;
    fp =filp_open("/root/storage.txt",O_RDWR | O_CREAT,0644);
    if (IS_ERR(fp)){
        printk("create file error/n");
        return ;
    }
    fs =get_fs();
    set_fs(KERNEL_DS);
    pos =0;
    vfs_write(fp,sbuf,size,&pos);
    filp_close(fp,NULL);
    set_fs(fs);
}
struct ch{
char a;
char b;
char c[2];
};
struct num{
int a;
int b;
int c[2];
};
static struct timer_list my_timer ;
char *buf;
char *sbuf;
int total=0;
void timer_handler( unsigned long data )
{    
	printk("this is a test for timer .\n");
	vfswr(sbuf,total);
	my_timer.expires = jiffies + 5*HZ ;
	add_timer( &my_timer );                   
	return ;    
}
void timer(void)                     
{
    init_timer( &my_timer );
    my_timer.data = 0 ;
    my_timer.expires = jiffies + 15*HZ ;
    my_timer.function = timer_handler ;
    add_timer( &my_timer );
    return  ;

}
static int __init dsr_module_init(void)
{
buf=(char *)kmalloc(20*sizeof(char),GFP_ATOMIC);
sbuf=buf;
struct ch *nch=(struct ch *)kmalloc(sizeof(struct ch),GFP_ATOMIC);
nch->a='a';
nch->b='b';
nch->c[0]='a';
nch->c[1]='b';
struct num *nnum=(struct num *)kmalloc(sizeof(struct num),GFP_ATOMIC);
nnum->a=1;
nnum->b=2;
nnum->c[0]=1;
nnum->c[1]=2;
char *pch=(char *)nch;
char *pnum=(char *)nnum;
memcpy(buf,pch,sizeof(*nch));
buf+=sizeof(*nch);
memcpy(buf,pnum,sizeof(*nnum));
total=sizeof(*nch)+sizeof(*nnum);
timer(); 
return 0;
}

static void __exit dsr_module_cleanup(void)
{
    printk("<1>Exiting...\n");
    del_timer( &my_timer);      
    printk("<1>Byebye! \n");    
    return ;
}

module_init(dsr_module_init);
module_exit(dsr_module_cleanup);
